import React ,{Component} from 'react';

class Counter extends Component{
constructor(props){
  super(props);
  this.state 	= {show:'none',nArray:'',thumbnailUrl:'',url:'',title:'',id:'',albumId:'',a:'',layout:true,searchs:''};

  this.EditData = this.EditData.bind(this); 
  this.Close = this.Close.bind(this);
  this.updateHandle= this.updateHandle.bind(this);
  this.changeHandle = this.changeHandle.bind(this);
  this.AddData = this.AddData.bind(this);
  this.layoutdata = this.layoutdata.bind(this);
  this.SearchDataItem = this.SearchDataItem.bind(this);
}

 componentDidMount(){	
    this.props.SearchData();
 }

   EditData(idx){
  // console.log(idx);
   let newArray = this.props.counter;  // console.log(newArray);
   this.setState({show:"block"});
   this.setState({nArray:newArray[idx],thumbnailUrl:newArray[idx].thumbnailUrl,url:newArray[idx].url,title:newArray[idx].title,id:newArray[idx].id,albumId:newArray[idx].albumId});                
}

 AddData(){   
   let sts= this.state.nArray; console.log(sts); 
   this.setState({show:"block"});
  let obj ={albumId: '', id: '', title: " ", url: " ", thumbnailUrl:" " };
   this.setState({nArray:obj,thumbnailUrl:'',url:'',title:'',id:'',albumId:''});                
}


Close(){
 this.setState({show:"none"});
}
updateHandle(event){   
    event.preventDefault(); 
    event.stopPropagation();
 
   this.props.decrement(this.state.nArray);
   this.setState({show:"none"});
 
}
 changeHandle(event){
   let ndata 	= this.state;
   var name 	= event.target.name; 
  
   let id = Object.keys(this.props.counter).length;

   ndata[name]  = event.target.value; 
   if(ndata.id==='')
	ndata['id']=id+1;
 
   this.setState({nArray:ndata});
}

layoutdata(){

 let idx = this.state.layout;
  if(idx===false)
  	 this.setState({layout:true});
  else
  	this.setState({layout:false});
}

SearchDataItem(e){

  //let state = this.state;
 // var names = e.target.name;
  let searchdata  = e.target.value;
 
 this.setState({searchs:searchdata});
  const lowercasedValue = searchdata.toLowerCase().trim();
  this.props.FilterData(lowercasedValue);
}

render(){
  const {counter,decrement,SearchData,Deletedata,FilterData} = this.props;

return(
        <div>
	<button onClick={SearchData}>Refresh</button>
	<button onClick={this.AddData}>Add </button>
	
         {
	  this.state.layout?<button onClick={this.layoutdata}>Table</button>:<button onClick={this.layoutdata}>Layout</button>
	 }
        <input type="text" value={this.state.searchs} name="searchs" placeholder="Search" onChange={(e)=>this.SearchDataItem(e)}/>

	<div className="w3-container" style={{display:this.state.layout?'none':'block'}}>		
		<table style={{fontSize:"12px"}} className="w3-table-all"> 
		  <thead>
		  <tr className="w3-red">	
		  <th>SNO</th>			
		  <th>Id</th>
		  <th>Title</th>	     
		  <th>Url</th>
 		  <th>Thumbnailurl</th>		
		  <th>Action</th>
		  </tr> 
		 </thead>
		  <tbody>	
			{			 
			Object.keys(this.props.counter).map((key, i) => {
			return <tr key={i}><td>{(i+1)} </td><td>{this.props.counter[key].id}</td><td>{this.props.counter[key].title}</td>
		        <td>{this.props.counter[key].url}</td><td>{this.props.counter[key].thumbnailUrl}</td>
		        <td><button onClick={()=>Deletedata(i)}>Delete</button><button onClick={()=>this.EditData(i)}>Edit</button></td>
		        </tr>		        
		  })
	  }	
		  {/*		
			  this.props.mydata.map((item, i) => {
			 return <tr key={i}><td>{(i+1)}</td><td>{item.id}</td><td>{item.title}</td><td>{item.completed}</td></tr>		        
		  })
		  */}
		  </tbody>
		  </table>
  
   { /*
   this.props.mydata.todos.map((item,index)=>{
   return <p>{item[index].title}</p>
	  
  
   })
  */}
  
 </div>
 <div className="w3-container" style={{display:this.state.layout?'block':'none'}}>
{
	Object.keys(this.props.counter).map((key, i) => {
	 return(<>
		
		<div className="w3-quarter w3-container w3-green"><div className="w3-panel">{this.props.counter[key].title.substr(0, 30)}</div></div>
		<div className="w3-quarter w3-container w3-yellow" ><div className="w3-panel">{this.props.counter[key].url.substr(0, 30)}</div></div>
		<div className="w3-quarter w3-container w3-red">  <div className="w3-panel">{this.props.counter[key].thumbnailUrl.substr(0,30)}</div></div>
		<div className="w3-quarter w3-container w3-grey"><div className="w3-panel w3-right">
		<button className="w3-button w3-red" onClick={()=>Deletedata(i)}>Delete</button>&nbsp;
		<button className="w3-button w3-orange" onClick={()=>this.EditData(i)}>Edit</button></div></div>
		</>
		
	);
    })
}
	
</div>
  <Model show={this.state.show} mydata={this.state.nArray} thumbnailUrl={this.state.thumbnailUrl} url={this.state.url} title={this.state.title} albumId={this.state.albumId} id={this.state.id} Close={this.Close} updateHandle={this.updateHandle} changeHandle={this.changeHandle}/>
</div>
);	
}
}

function Model(props) {
  //console.log(props.mydata);
 return(
	<div id="id01" className="w3-modal" style={{display:props.show}}>
	<div className="w3-modal-content">
		<header className="w3-container w3-red"> 
			<span  onClick={props.Close}className="w3-button w3-display-topright">&times;</span>
			<h5>Update</h5>
		</header>
	<div className="w3-container">
		<form className="w3-container" onSubmit={(event)=>props.updateHandle(event)}>		 
			
			  <p>      
			  <label className="w3-text-blue"><b>Title</b></label>
			  <input className="w3-input w3-border" name="title" type="text" value={props.mydata.title} onChange={(e)=>props.changeHandle(e)}/></p>
			  <p>      
			  <label className="w3-text-blue"><b>Url</b></label>
			  <input className="w3-input w3-border" name="url" type="text" value={props.mydata.url} onChange={(e)=>props.changeHandle(e)}/></p>
			<p>      
			<label className="w3-text-blue"><b>ThumbnailUrl</b></label>
			<input className="w3-input w3-border" name="thumbnailUrl" type="text" value={props.mydata.thumbnailUrl} onChange={(e)=>props.changeHandle(e)}/></p>
			
			<p>      
			  <button className="w3-btn w3-blue">Register</button></p>
		</form>
	</div>
		<footer className="w3-container w3-red">
		<p>Modal Footer</p>
		</footer>
	</div>
	</div>
);

}

export default Counter;
