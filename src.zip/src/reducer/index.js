const reducer =(state=0,action)=>{
 switch(action.type){
	
	case"UPDATE":
                  let sIDx ={...state};
                  let ids = action.payload.id -1 ;
		  var size1 = Object.values(sIDx);		   
                     size1[ids]=action.payload;

		return size1;	
	
	case"SEARCHDATA":       
		return action.payload;

	case"DELETE":
		let newArray = {...state};
		let size = Object.values(newArray);
		 size.splice(action.payload,1);      
		return size;

	case"SEARCH":
	        const excludeColumns = ["url"];
 		  let sIds ={...state};                 
		  var size1 =Object.values(sIds);
		  let newState =[...size1];
                  const lowercasedValue = action.payload;
	  	  const filteredData = newState.filter(item => {
     		    return Object.keys(item).some(key =>
         		 excludeColumns.includes(key) ?'' : item[key].toString().toLowerCase().includes(lowercasedValue)
       			 );
     	 });  
          
	 return filteredData;
      	
     default:
	return 0;
}
}
export default reducer;


