import {connect} from 'react-redux';
import Counter from '../component/counter';

import {decrement,SearchData,Deletedata,FilterData} from '../action';
const mapStateToProps =(state)=>{
 return {
  counter : state,
  
};

}
const mapDispatchToProps=(dispatch,ownProps)=>{
return {

 decrement:(idx)=>dispatch(decrement(idx)),
 Deletedata :(idx)=>dispatch(Deletedata(idx)),
 SearchData:()=>dispatch(SearchData()),
FilterData:(idx)=>dispatch(FilterData(idx))
};
}
export default connect(mapStateToProps,mapDispatchToProps)(Counter);
