import React, { Component } from "react";
//import Account from "./Account";
//import Hooks from "./component/Hooks";
import Counter from "./container/counterContainer";
class App extends Component {
  
  

  render() {
   
    return (
      <React.Fragment>
	 <Counter/>		
      
      </React.Fragment>
    );
  }
}

export default App;
